import { Request, Response, NextFunction } from "express";
import { ZodSchema } from "zod";
import { ApiError } from "../utils/apiError";

// Frontend validation is a UX nicety only — this is the enforcement point.
// Any endpoint that accepts a body/query must run through one of these.
export function validateBody(schema: ZodSchema) {
  return (req: Request, res: Response, next: NextFunction) => {
    const result = schema.safeParse(req.body);
    if (!result.success) {
      return next(ApiError.badRequest(result.error.issues.map((i) => i.message).join(", "), "VALIDATION_ERROR"));
    }
    req.body = result.data;
    next();
  };
}

export function validateQuery(schema: ZodSchema) {
  return (req: Request, res: Response, next: NextFunction) => {
    const result = schema.safeParse(req.query);
    if (!result.success) {
      return next(ApiError.badRequest(result.error.issues.map((i) => i.message).join(", "), "VALIDATION_ERROR"));
    }
    (req as any).validatedQuery = result.data;
    next();
  };
}
