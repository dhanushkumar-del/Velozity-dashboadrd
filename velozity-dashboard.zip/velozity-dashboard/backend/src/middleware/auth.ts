import { Request, Response, NextFunction } from "express";
import { Role } from "@prisma/client";
import { verifyAccessToken } from "../utils/jwt";
import { ApiError } from "../utils/apiError";

export interface AuthedRequest extends Request {
  user?: { id: string; role: Role };
}

/**
 * Verifies the access token on every protected route. This is the single
 * choke point all API traffic passes through — there is no route that trusts
 * a client-supplied role or id for anything. A Developer who edits their JWT
 * payload client-side gets a signature-verification failure here, not a
 * hidden-but-reachable endpoint.
 */
export function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    return next(ApiError.unauthorized("Missing access token"));
  }
  const token = header.slice("Bearer ".length);
  try {
    const payload = verifyAccessToken(token);
    req.user = { id: payload.sub, role: payload.role };
    next();
  } catch {
    next(ApiError.unauthorized("Invalid or expired access token"));
  }
}

/**
 * Role gate. Stacks after requireAuth. This is deliberately a hard allow-list,
 * not a deny-list, so adding a new role later can't accidentally fall through
 * as authorized.
 */
export function requireRole(...roles: Role[]) {
  return (req: AuthedRequest, res: Response, next: NextFunction) => {
    if (!req.user) return next(ApiError.unauthorized());
    if (!roles.includes(req.user.role)) {
      return next(ApiError.forbidden("You do not have permission to perform this action"));
    }
    next();
  };
}
