import { Router, Response, NextFunction } from "express";
import { prisma } from "../config/prisma";
import { requireAuth, AuthedRequest } from "../middleware/auth";

const router = Router();
router.use(requireAuth);

router.get("/", async (req: AuthedRequest, res: Response, next: NextFunction) => {
  try {
    const notifications = await prisma.notification.findMany({
      where: { userId: req.user!.id },
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    const unreadCount = await prisma.notification.count({ where: { userId: req.user!.id, isRead: false } });
    res.json({ success: true, data: { notifications, unreadCount } });
  } catch (err) {
    next(err);
  }
});

router.patch("/:id/read", async (req: AuthedRequest, res: Response, next: NextFunction) => {
  try {
    // updateMany + userId filter, not update-by-id-alone: prevents one user
    // from marking another user's notification as read via a guessed id.
    await prisma.notification.updateMany({
      where: { id: req.params.id, userId: req.user!.id },
      data: { isRead: true },
    });
    res.json({ success: true, data: null });
  } catch (err) {
    next(err);
  }
});

router.patch("/read-all", async (req: AuthedRequest, res: Response, next: NextFunction) => {
  try {
    await prisma.notification.updateMany({ where: { userId: req.user!.id, isRead: false }, data: { isRead: true } });
    res.json({ success: true, data: null });
  } catch (err) {
    next(err);
  }
});

export default router;
