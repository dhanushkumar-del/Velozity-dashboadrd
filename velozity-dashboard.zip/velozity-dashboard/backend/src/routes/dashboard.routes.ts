import { Router, Response, NextFunction } from "express";
import { Role } from "@prisma/client";
import { prisma } from "../config/prisma";
import { requireAuth, AuthedRequest } from "../middleware/auth";
import { getOnlineCount } from "../services/socket.service";

const router = Router();
router.use(requireAuth);

router.get("/", async (req: AuthedRequest, res: Response, next: NextFunction) => {
  try {
    const user = req.user!;

    if (user.role === Role.ADMIN) {
      const [totalProjects, tasksByStatus, overdueCount] = await Promise.all([
        prisma.project.count(),
        prisma.task.groupBy({ by: ["status"], _count: true }),
        prisma.task.count({ where: { isOverdue: true } }),
      ]);
      return res.json({
        success: true,
        data: { totalProjects, tasksByStatus, overdueCount, onlineUsers: getOnlineCount() },
      });
    }

    if (user.role === Role.PM) {
      const weekFromNow = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      const [projects, tasksByPriority, upcomingDue] = await Promise.all([
        prisma.project.findMany({ where: { ownerId: user.id }, include: { _count: { select: { tasks: true } } } }),
        prisma.task.groupBy({ by: ["priority"], where: { project: { ownerId: user.id } }, _count: true }),
        prisma.task.findMany({
          where: { project: { ownerId: user.id }, dueDate: { gte: new Date(), lte: weekFromNow } },
          orderBy: { dueDate: "asc" },
        }),
      ]);
      return res.json({ success: true, data: { projects, tasksByPriority, upcomingDue } });
    }

    // Developer
    const myTasks = await prisma.task.findMany({
      where: { assigneeId: user.id },
      orderBy: [{ priority: "desc" }, { dueDate: "asc" }],
      include: { project: { select: { name: true } } },
    });
    return res.json({ success: true, data: { myTasks } });
  } catch (err) {
    next(err);
  }
});

export default router;
