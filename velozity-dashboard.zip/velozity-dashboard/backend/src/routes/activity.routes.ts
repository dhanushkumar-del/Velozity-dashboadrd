import { Router } from "express";
import { requireAuth, AuthedRequest } from "../middleware/auth";
import { getRecentActivity } from "../services/activity.service";
import { Response, NextFunction } from "express";

const router = Router();
router.use(requireAuth);

// GET /api/activity?since=<ISO timestamp>  -> last 20 missed events, role-filtered
router.get("/", async (req: AuthedRequest, res: Response, next: NextFunction) => {
  try {
    const since = req.query.since ? new Date(req.query.since as string) : undefined;
    const events = await getRecentActivity(req.user!.id, req.user!.role, since, 20);
    res.json({ success: true, data: events });
  } catch (err) {
    next(err);
  }
});

export default router;
