import { Router } from "express";
import { z } from "zod";
import { Role } from "@prisma/client";
import { requireAuth, requireRole } from "../middleware/auth";
import { validateBody } from "../middleware/validate";
import { createTask, listTasks, getTask, updateTask } from "../controllers/task.controller";

const router = Router();

const createSchema = z.object({
  projectId: z.string().uuid(),
  title: z.string().min(1),
  description: z.string().optional(),
  assigneeId: z.string().uuid().optional(),
  priority: z.enum(["LOW", "MEDIUM", "HIGH", "CRITICAL"]).optional(),
  dueDate: z.string().datetime().optional(),
});

const updateSchema = z.object({
  status: z.enum(["TODO", "IN_PROGRESS", "IN_REVIEW", "DONE"]).optional(),
  priority: z.enum(["LOW", "MEDIUM", "HIGH", "CRITICAL"]).optional(),
  assigneeId: z.string().uuid().nullable().optional(),
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  dueDate: z.string().datetime().nullable().optional(),
});

router.use(requireAuth);
router.get("/", listTasks); // scoped by role inside controller
router.get("/:id", getTask); // access-checked inside controller
router.post("/", requireRole(Role.ADMIN, Role.PM), validateBody(createSchema), createTask);
router.patch("/:id", validateBody(updateSchema), updateTask); // Devs allowed, but limited to status inside controller

export default router;
