import { Router, Response, NextFunction } from "express";
import { Role } from "@prisma/client";
import { prisma } from "../config/prisma";
import { requireAuth, requireRole, AuthedRequest } from "../middleware/auth";

export const usersRouter = Router();
usersRouter.use(requireAuth, requireRole(Role.ADMIN, Role.PM));

usersRouter.get("/developers", async (_req: AuthedRequest, res: Response, next: NextFunction) => {
  try {
    const developers = await prisma.user.findMany({
      where: { role: Role.DEVELOPER },
      select: { id: true, name: true, email: true },
    });
    res.json({ success: true, data: developers });
  } catch (err) {
    next(err);
  }
});

export const clientsRouter = Router();
clientsRouter.use(requireAuth, requireRole(Role.ADMIN, Role.PM));

clientsRouter.get("/", async (_req: AuthedRequest, res: Response, next: NextFunction) => {
  try {
    const clients = await prisma.client.findMany();
    res.json({ success: true, data: clients });
  } catch (err) {
    next(err);
  }
});
