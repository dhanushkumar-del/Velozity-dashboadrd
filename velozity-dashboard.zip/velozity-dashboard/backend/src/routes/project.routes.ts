import { Router } from "express";
import { z } from "zod";
import { Role } from "@prisma/client";
import { requireAuth, requireRole } from "../middleware/auth";
import { validateBody } from "../middleware/validate";
import { createProject, listProjects, getProject, updateProject } from "../controllers/project.controller";

const router = Router();

const createSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  clientId: z.string().uuid(),
  ownerId: z.string().uuid().optional(),
});

const updateSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
});

router.use(requireAuth);
// Everyone authenticated can list/view — the controller scopes results by role.
router.get("/", listProjects);
router.get("/:id", getProject);
// Only Admin and PM can create/edit projects at all.
router.post("/", requireRole(Role.ADMIN, Role.PM), validateBody(createSchema), createProject);
router.patch("/:id", requireRole(Role.ADMIN, Role.PM), validateBody(updateSchema), updateProject);

export default router;
