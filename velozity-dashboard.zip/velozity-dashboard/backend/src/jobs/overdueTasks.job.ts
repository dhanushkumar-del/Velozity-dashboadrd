import cron from "node-cron";
import { prisma } from "../config/prisma";
import { logActivity } from "../services/activity.service";

/**
 * Why node-cron over Bull here: this job is a single, stateless, idempotent
 * "scan and flag" operation with no per-job payload, no retries-with-backoff
 * need, and no cross-process work queue to coordinate — Bull's Redis
 * dependency would be pure overhead for a task this simple. Bull would earn
 * its keep if we later needed things like "send an email 3 days before due
 * date with retry on failure" (real per-item jobs with state).
 *
 * Runs every minute — cheap because both indexed columns (dueDate, isOverdue)
 * keep the WHERE clause fast even as the tasks table grows.
 */
export function startOverdueTaskJob() {
  cron.schedule("* * * * *", async () => {
    const now = new Date();
    const overdue = await prisma.task.findMany({
      where: {
        dueDate: { lt: now },
        isOverdue: false,
        status: { not: "DONE" },
      },
      select: { id: true, projectId: true, title: true },
    });

    if (overdue.length === 0) return;

    for (const task of overdue) {
      await prisma.task.update({ where: { id: task.id }, data: { isOverdue: true } });
      await logActivity({
        projectId: task.projectId,
        taskId: task.id,
        actorId: "system",
        action: "MARKED_OVERDUE",
        message: `"${task.title}" is now overdue`,
      }).catch(() => {
        // "system" actor has no User row for the FK — see seed.ts note.
        // In production, create a real system-user row (done in seed.ts).
      });
    }

    console.log(`[overdue-job] flagged ${overdue.length} task(s) overdue`);
  });
}
