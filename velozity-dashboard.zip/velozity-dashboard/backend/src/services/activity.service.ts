import { prisma } from "../config/prisma";
import { Role } from "@prisma/client";
import { emitActivity } from "./socket.service";

export async function logActivity(params: {
  projectId: string;
  taskId?: string;
  actorId: string;
  action: string;
  fromValue?: string;
  toValue?: string;
  message: string;
}) {
  const entry = await prisma.activityLog.create({
    data: {
      projectId: params.projectId,
      taskId: params.taskId,
      actorId: params.actorId,
      action: params.action,
      fromValue: params.fromValue,
      toValue: params.toValue,
      message: params.message,
    },
    include: { actor: true, project: true },
  });

  emitActivity({
    projectId: entry.projectId,
    projectOwnerId: entry.project.ownerId,
    taskAssigneeId: params.taskId
      ? (await prisma.task.findUnique({ where: { id: params.taskId } }))?.assigneeId
      : null,
    event: {
      id: entry.id,
      message: entry.message,
      action: entry.action,
      createdAt: entry.createdAt,
      actorId: entry.actorId,
      actorName: entry.actor.name,
      taskId: entry.taskId,
    },
  });

  return entry;
}

/**
 * Missed-event catchup: when a client reconnects, it calls this (via the
 * REST endpoint) with the timestamp of the last event it saw. This always
 * reads from the database — nothing is cached in memory, so it survives
 * server restarts and works even if the user was offline for days.
 */
export async function getRecentActivity(userId: string, role: Role, since?: Date, limit = 20) {
  if (role === Role.ADMIN) {
    return prisma.activityLog.findMany({
      where: since ? { createdAt: { gt: since } } : {},
      orderBy: { createdAt: "desc" },
      take: limit,
      include: { actor: { select: { name: true } } },
    });
  }

  if (role === Role.PM) {
    return prisma.activityLog.findMany({
      where: {
        project: { ownerId: userId },
        ...(since ? { createdAt: { gt: since } } : {}),
      },
      orderBy: { createdAt: "desc" },
      take: limit,
      include: { actor: { select: { name: true } } },
    });
  }

  // Developer: only activity on tasks assigned to them
  return prisma.activityLog.findMany({
    where: {
      task: { assigneeId: userId },
      ...(since ? { createdAt: { gt: since } } : {}),
    },
    orderBy: { createdAt: "desc" },
    take: limit,
    include: { actor: { select: { name: true } } },
  });
}
