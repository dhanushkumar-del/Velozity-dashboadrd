import { Server as HttpServer } from "http";
import { Server, Socket } from "socket.io";
import { Role } from "@prisma/client";
import { verifyAccessToken } from "../utils/jwt";
import { prisma } from "../config/prisma";
import { env } from "../config/env";

/**
 * ROOM STRATEGY — this is the core of the real-time role-filtering.
 *
 * We do NOT trust the client to only listen to events it's "supposed to".
 * Every room join is permission-checked server-side at join time, and every
 * emission is fanned out to a fixed, precomputed set of rooms server-side.
 * A Developer's client code could subscribe to any event name it wants —
 * it will simply never be placed in a room that receives Admin/PM-only data.
 *
 * Rooms:
 *  - "feed:global"        Admin's global activity feed
 *  - "feed:pm:<pmId>"     A PM's feed, scoped to projects they own
 *  - "feed:dev:<devId>"   A Developer's feed, scoped to tasks assigned to them
 *  - "project:<id>"       Live task-board viewers for a specific project page
 *                          (joined explicitly via "project:view", checked
 *                          against the viewer's role/ownership/assignment)
 */

interface AuthedSocket extends Socket {
  userId?: string;
  role?: Role;
}

let io: Server;
const onlineUsers = new Map<string, number>(); // userId -> connection count (multi-tab)

export function initSocket(httpServer: HttpServer) {
  io = new Server(httpServer, {
    cors: { origin: env.corsOrigin, credentials: true },
  });

  io.use((socket: AuthedSocket, next) => {
    try {
      const token = socket.handshake.auth?.token as string | undefined;
      if (!token) return next(new Error("No token"));
      const payload = verifyAccessToken(token);
      socket.userId = payload.sub;
      socket.role = payload.role;
      next();
    } catch {
      next(new Error("Invalid token"));
    }
  });

  io.on("connection", async (socket: AuthedSocket) => {
    const { userId, role } = socket;
    if (!userId || !role) return socket.disconnect();

    // Join the correct personal feed room based on role.
    if (role === Role.ADMIN) {
      socket.join("feed:global");
    } else if (role === Role.PM) {
      socket.join(`feed:pm:${userId}`);
    } else {
      socket.join(`feed:dev:${userId}`);
    }

    onlineUsers.set(userId, (onlineUsers.get(userId) || 0) + 1);
    broadcastPresence();

    socket.on("project:view", async (projectId: string, ack?: (ok: boolean) => void) => {
      const allowed = await canViewProject(userId, role, projectId);
      if (allowed) {
        socket.join(`project:${projectId}`);
        ack?.(true);
      } else {
        ack?.(false);
      }
    });

    socket.on("project:leave", (projectId: string) => {
      socket.leave(`project:${projectId}`);
    });

    socket.on("disconnect", () => {
      const count = (onlineUsers.get(userId) || 1) - 1;
      if (count <= 0) onlineUsers.delete(userId);
      else onlineUsers.set(userId, count);
      broadcastPresence();
    });
  });

  return io;
}

async function canViewProject(userId: string, role: Role, projectId: string): Promise<boolean> {
  if (role === Role.ADMIN) return true;
  if (role === Role.PM) {
    const project = await prisma.project.findUnique({ where: { id: projectId } });
    return project?.ownerId === userId;
  }
  // Developer: allowed only if they have at least one task in the project
  const task = await prisma.task.findFirst({ where: { projectId, assigneeId: userId } });
  return !!task;
}

function broadcastPresence() {
  io.to("feed:global").emit("presence:count", onlineUsers.size);
}

export function getOnlineCount() {
  return onlineUsers.size;
}

/**
 * Called by the activity service whenever a new ActivityLog row is written.
 * Fans out to exactly the rooms whose viewers are entitled to see it —
 * this is what makes the feed "role-filtered" rather than "filtered on
 * the client after receiving everything".
 */
export function emitActivity(params: {
  projectId: string;
  projectOwnerId: string;
  taskAssigneeId?: string | null;
  event: {
    id: string;
    message: string;
    action: string;
    createdAt: Date;
    actorId: string;
    actorName: string;
    taskId?: string | null;
  };
}) {
  const { projectId, projectOwnerId, taskAssigneeId, event } = params;

  io.to("feed:global").emit("activity:new", event);
  io.to(`feed:pm:${projectOwnerId}`).emit("activity:new", event);
  if (taskAssigneeId) {
    io.to(`feed:dev:${taskAssigneeId}`).emit("activity:new", event);
  }
  // Anyone actively viewing this project's board (regardless of role)
  io.to(`project:${projectId}`).emit("activity:new", event);
}

export function emitNotification(userId: string, notification: { id: string; message: string; createdAt: Date; taskId?: string | null }) {
  io.to(`feed:pm:${userId}`).emit("notification:new", notification);
  io.to(`feed:dev:${userId}`).emit("notification:new", notification);
  io.to("feed:global").emit("notification:new", notification); // admin also sees it if they are the target user
}
