import { prisma } from "../config/prisma";
import { emitNotification } from "./socket.service";

export async function notify(userId: string, message: string, taskId?: string) {
  const n = await prisma.notification.create({
    data: { userId, message, taskId },
  });
  emitNotification(userId, { id: n.id, message: n.message, createdAt: n.createdAt, taskId: n.taskId });
  return n;
}
