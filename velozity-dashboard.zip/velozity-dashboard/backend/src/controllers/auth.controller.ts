import { Request, Response, NextFunction } from "express";
import bcrypt from "bcrypt";
import { prisma } from "../config/prisma";
import { ApiError } from "../utils/apiError";
import { signAccessToken, generateRefreshToken, hashRefreshToken } from "../utils/jwt";
import { env } from "../config/env";
import { AuthedRequest } from "../middleware/auth";

const REFRESH_COOKIE = "refresh_token";

function refreshCookieOptions() {
  return {
    httpOnly: true, // not readable by JS — mitigates XSS token theft
    secure: env.isProd, // HTTPS only in production
    sameSite: "lax" as const,
    path: "/api/auth", // only sent to the refresh/logout endpoints
    maxAge: env.refreshTokenTtlDays * 24 * 60 * 60 * 1000,
  };
}

async function issueTokens(userId: string, role: any, res: Response) {
  const accessToken = signAccessToken({ sub: userId, role });
  const { token: refreshToken, hash } = generateRefreshToken();

  await prisma.refreshToken.create({
    data: {
      userId,
      tokenHash: hash,
      expiresAt: new Date(Date.now() + env.refreshTokenTtlDays * 24 * 60 * 60 * 1000),
    },
  });

  res.cookie(REFRESH_COOKIE, refreshToken, refreshCookieOptions());
  return accessToken;
}

export async function login(req: Request, res: Response, next: NextFunction) {
  try {
    const { email, password } = req.body;
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) throw ApiError.unauthorized("Invalid credentials");

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) throw ApiError.unauthorized("Invalid credentials");

    const accessToken = await issueTokens(user.id, user.role, res);
    res.json({
      success: true,
      data: { accessToken, user: { id: user.id, name: user.name, email: user.email, role: user.role } },
    });
  } catch (err) {
    next(err);
  }
}

export async function refresh(req: Request, res: Response, next: NextFunction) {
  try {
    const token = req.cookies?.[REFRESH_COOKIE];
    if (!token) throw ApiError.unauthorized("No refresh token");

    const hash = hashRefreshToken(token);
    const record = await prisma.refreshToken.findUnique({ where: { tokenHash: hash }, include: { user: true } });

    if (!record || record.revoked || record.expiresAt < new Date()) {
      throw ApiError.unauthorized("Refresh token invalid or expired");
    }

    // Rotate: revoke the old one, issue a new one. Prevents replay of a
    // stolen-but-already-used refresh token.
    await prisma.refreshToken.update({ where: { id: record.id }, data: { revoked: true } });
    const accessToken = await issueTokens(record.userId, record.user.role, res);

    res.json({
      success: true,
      data: {
        accessToken,
        user: { id: record.user.id, name: record.user.name, email: record.user.email, role: record.user.role },
      },
    });
  } catch (err) {
    next(err);
  }
}

export async function logout(req: Request, res: Response, next: NextFunction) {
  try {
    const token = req.cookies?.[REFRESH_COOKIE];
    if (token) {
      const hash = hashRefreshToken(token);
      await prisma.refreshToken.updateMany({ where: { tokenHash: hash }, data: { revoked: true } });
    }
    res.clearCookie(REFRESH_COOKIE, { path: "/api/auth" });
    res.json({ success: true, data: null });
  } catch (err) {
    next(err);
  }
}

export async function me(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user) throw ApiError.notFound("User not found");
    res.json({ success: true, data: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    next(err);
  }
}
