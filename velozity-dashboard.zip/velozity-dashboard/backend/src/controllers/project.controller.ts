import { Response, NextFunction } from "express";
import { Role } from "@prisma/client";
import { prisma } from "../config/prisma";
import { AuthedRequest } from "../middleware/auth";
import { ApiError } from "../utils/apiError";

export async function createProject(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const { name, description, clientId, ownerId } = req.body;
    const user = req.user!;

    // A PM can only create projects owned by themselves. Only an Admin may
    // set an arbitrary ownerId (e.g. creating a project on a PM's behalf).
    const finalOwnerId = user.role === Role.ADMIN && ownerId ? ownerId : user.id;
    if (user.role === Role.PM && ownerId && ownerId !== user.id) {
      throw ApiError.forbidden("PMs cannot create projects owned by another PM");
    }

    const project = await prisma.project.create({
      data: { name, description, clientId, ownerId: finalOwnerId },
    });
    res.status(201).json({ success: true, data: project });
  } catch (err) {
    next(err);
  }
}

export async function listProjects(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const user = req.user!;
    let where = {};

    // This is the enforcement point, not a frontend filter: the WHERE clause
    // itself makes another PM's projects unreachable, regardless of what the
    // client requests.
    if (user.role === Role.PM) {
      where = { ownerId: user.id };
    } else if (user.role === Role.DEVELOPER) {
      where = { tasks: { some: { assigneeId: user.id } } };
    }
    // Admin: no filter, sees everything.

    const projects = await prisma.project.findMany({
      where,
      include: { client: true, _count: { select: { tasks: true } } },
      orderBy: { createdAt: "desc" },
    });
    res.json({ success: true, data: projects });
  } catch (err) {
    next(err);
  }
}

async function assertProjectAccess(projectId: string, user: { id: string; role: Role }) {
  const project = await prisma.project.findUnique({ where: { id: projectId } });
  if (!project) throw ApiError.notFound("Project not found");

  if (user.role === Role.PM && project.ownerId !== user.id) {
    throw ApiError.forbidden("You do not own this project");
  }
  if (user.role === Role.DEVELOPER) {
    const hasTask = await prisma.task.findFirst({ where: { projectId, assigneeId: user.id } });
    if (!hasTask) throw ApiError.forbidden("You have no tasks in this project");
  }
  return project;
}

export async function getProject(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const project = await assertProjectAccess(req.params.id, req.user!);
    res.json({ success: true, data: project });
  } catch (err) {
    next(err);
  }
}

export async function updateProject(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const user = req.user!;
    const project = await prisma.project.findUnique({ where: { id: req.params.id } });
    if (!project) throw ApiError.notFound("Project not found");

    if (user.role === Role.PM && project.ownerId !== user.id) {
      throw ApiError.forbidden("You do not own this project");
    }
    if (user.role === Role.DEVELOPER) {
      throw ApiError.forbidden("Developers cannot edit projects");
    }

    const updated = await prisma.project.update({
      where: { id: req.params.id },
      data: { name: req.body.name, description: req.body.description },
    });
    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
}
