import { Response, NextFunction } from "express";
import { Role, TaskStatus, Prisma } from "@prisma/client";
import { prisma } from "../config/prisma";
import { AuthedRequest } from "../middleware/auth";
import { ApiError } from "../utils/apiError";
import { logActivity } from "../services/activity.service";
import { notify } from "../services/notification.service";

const STATUS_LABEL: Record<TaskStatus, string> = {
  TODO: "To Do",
  IN_PROGRESS: "In Progress",
  IN_REVIEW: "In Review",
  DONE: "Done",
};

export async function createTask(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const user = req.user!;
    const { projectId, title, description, assigneeId, priority, dueDate } = req.body;

    const project = await prisma.project.findUnique({ where: { id: projectId } });
    if (!project) throw ApiError.notFound("Project not found");
    if (user.role === Role.PM && project.ownerId !== user.id) {
      throw ApiError.forbidden("You do not own this project");
    }
    if (user.role === Role.DEVELOPER) {
      throw ApiError.forbidden("Developers cannot create tasks");
    }

    const task = await prisma.task.create({
      data: { projectId, title, description, assigneeId, priority, dueDate: dueDate ? new Date(dueDate) : null },
    });

    await logActivity({
      projectId,
      taskId: task.id,
      actorId: user.id,
      action: "TASK_CREATED",
      message: `Task "${title}" was created`,
    });

    if (assigneeId) {
      await notify(assigneeId, `You were assigned a new task: "${title}"`, task.id);
    }

    res.status(201).json({ success: true, data: task });
  } catch (err) {
    next(err);
  }
}

// Query params -> shareable-URL filters (status, priority, due date range, project)
export async function listTasks(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const user = req.user!;
    const { status, priority, projectId, dueBefore, dueAfter } = req.query as Record<string, string | undefined>;

    const where: Prisma.TaskWhereInput = {};
    if (status) where.status = status as TaskStatus;
    if (priority) where.priority = priority as any;
    if (projectId) where.projectId = projectId;
    if (dueBefore || dueAfter) {
      where.dueDate = {
        ...(dueBefore ? { lte: new Date(dueBefore) } : {}),
        ...(dueAfter ? { gte: new Date(dueAfter) } : {}),
      };
    }

    // Role scoping happens here, server-side, and cannot be overridden by
    // query params — a Developer sending ?assigneeId=someone-else is ignored.
    if (user.role === Role.DEVELOPER) {
      where.assigneeId = user.id;
    } else if (user.role === Role.PM) {
      where.project = { ownerId: user.id };
    }

    const tasks = await prisma.task.findMany({
      where,
      include: { assignee: { select: { id: true, name: true } }, project: { select: { id: true, name: true } } },
      orderBy: [{ priority: "desc" }, { dueDate: "asc" }],
    });

    res.json({ success: true, data: tasks });
  } catch (err) {
    next(err);
  }
}

async function loadTaskWithAccessCheck(taskId: string, user: { id: string; role: Role }) {
  const task = await prisma.task.findUnique({ where: { id: taskId }, include: { project: true } });
  if (!task) throw ApiError.notFound("Task not found");

  if (user.role === Role.PM && task.project.ownerId !== user.id) {
    throw ApiError.forbidden("You do not own this project");
  }
  if (user.role === Role.DEVELOPER && task.assigneeId !== user.id) {
    // This is the critical line: even with a perfectly valid, unmodified
    // token, a Developer gets 403 on any task not assigned to them —
    // including another developer's task in the same project.
    throw ApiError.forbidden("This task is not assigned to you");
  }
  return task;
}

export async function getTask(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const task = await loadTaskWithAccessCheck(req.params.id, req.user!);
    res.json({ success: true, data: task });
  } catch (err) {
    next(err);
  }
}

export async function updateTask(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const user = req.user!;
    const task = await loadTaskWithAccessCheck(req.params.id, user);
    const { status, priority, assigneeId, title, description, dueDate } = req.body;

    // Developers may only change status on their own task — not
    // reassign, retitle, or reprioritize it.
    if (user.role === Role.DEVELOPER) {
      const disallowed = [priority, assigneeId, title, description, dueDate].some((v) => v !== undefined);
      if (disallowed) throw ApiError.forbidden("Developers may only update task status");
    }

    const data: Prisma.TaskUpdateInput = {};
    if (status !== undefined) data.status = status;
    if (user.role !== Role.DEVELOPER) {
      if (priority !== undefined) data.priority = priority;
      if (title !== undefined) data.title = title;
      if (description !== undefined) data.description = description;
      if (dueDate !== undefined) data.dueDate = dueDate ? new Date(dueDate) : null;
      if (assigneeId !== undefined) data.assignee = assigneeId ? { connect: { id: assigneeId } } : { disconnect: true };
    }
    // Marking a task Done always clears the overdue flag, regardless of due date.
    if (status === "DONE") {
      data.isOverdue = false;
    }

    const updated = await prisma.task.update({ where: { id: req.params.id }, data });

    if (status && status !== task.status) {
      const actor = await prisma.user.findUnique({ where: { id: user.id } });
      await logActivity({
        projectId: task.projectId,
        taskId: task.id,
        actorId: user.id,
        action: "STATUS_CHANGE",
        fromValue: task.status,
        toValue: status,
        message: `${actor?.name} moved "${task.title}" from ${STATUS_LABEL[task.status]} \u2192 ${STATUS_LABEL[status as TaskStatus]}`,
      });

      if (status === "IN_REVIEW") {
        await notify(task.project.ownerId, `"${task.title}" was moved to In Review`, task.id);
      }
    }

    if (assigneeId && assigneeId !== task.assigneeId) {
      await notify(assigneeId, `You were assigned to "${task.title}"`, task.id);
    }

    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
}
