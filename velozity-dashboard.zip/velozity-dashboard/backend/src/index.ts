import express from "express";
import http from "http";
import cors from "cors";
import cookieParser from "cookie-parser";
import { env } from "./config/env";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler";
import { initSocket } from "./services/socket.service";
import { startOverdueTaskJob } from "./jobs/overdueTasks.job";

import authRoutes from "./routes/auth.routes";
import projectRoutes from "./routes/project.routes";
import taskRoutes from "./routes/task.routes";
import activityRoutes from "./routes/activity.routes";
import notificationRoutes from "./routes/notification.routes";
import dashboardRoutes from "./routes/dashboard.routes";
import { usersRouter, clientsRouter } from "./routes/lookup.routes";

const app = express();
const httpServer = http.createServer(app);

app.use(cors({ origin: env.corsOrigin, credentials: true }));
app.use(express.json());
app.use(cookieParser());

app.get("/health", (_req, res) => res.json({ ok: true }));

app.use("/api/auth", authRoutes);
app.use("/api/projects", projectRoutes);
app.use("/api/tasks", taskRoutes);
app.use("/api/activity", activityRoutes);
app.use("/api/notifications", notificationRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/users", usersRouter);
app.use("/api/clients", clientsRouter);

app.use(notFoundHandler);
app.use(errorHandler);

initSocket(httpServer);
startOverdueTaskJob();

httpServer.listen(env.port, () => {
  console.log(`Velozity backend listening on :${env.port}`);
});
