import { PrismaClient, Role, TaskStatus, TaskPriority } from "@prisma/client";
import bcrypt from "bcrypt";

const prisma = new PrismaClient();

async function hash(pw: string) {
  return bcrypt.hash(pw, 10);
}

async function main() {
  console.log("Seeding...");

  // Fixed-id "system" user so the overdue cron job can attribute activity
  // log rows to something other than a real human actor.
  await prisma.user.upsert({
    where: { id: "system" },
    update: {},
    create: {
      id: "system",
      name: "System",
      email: "system@internal.velozity.local",
      passwordHash: await hash("not-a-real-login"),
      role: Role.ADMIN,
    },
  });

  const admin = await prisma.user.create({
    data: { name: "Priya Nair", email: "admin@velozity.com", passwordHash: await hash("Password123!"), role: Role.ADMIN },
  });

  const pm1 = await prisma.user.create({
    data: { name: "Sofia Reyes", email: "sofia.pm@velozity.com", passwordHash: await hash("Password123!"), role: Role.PM },
  });
  const pm2 = await prisma.user.create({
    data: { name: "Daniel Kim", email: "daniel.pm@velozity.com", passwordHash: await hash("Password123!"), role: Role.PM },
  });

  const dev1 = await prisma.user.create({
    data: { name: "Ravi Shah", email: "ravi.dev@velozity.com", passwordHash: await hash("Password123!"), role: Role.DEVELOPER },
  });
  const dev2 = await prisma.user.create({
    data: { name: "Maya Chen", email: "maya.dev@velozity.com", passwordHash: await hash("Password123!"), role: Role.DEVELOPER },
  });
  const dev3 = await prisma.user.create({
    data: { name: "Tomás Lopez", email: "tomas.dev@velozity.com", passwordHash: await hash("Password123!"), role: Role.DEVELOPER },
  });
  const dev4 = await prisma.user.create({
    data: { name: "Aisha Bello", email: "aisha.dev@velozity.com", passwordHash: await hash("Password123!"), role: Role.DEVELOPER },
  });

  const clientA = await prisma.client.create({ data: { name: "Northwind Retail", contact: "ops@northwind.example" } });
  const clientB = await prisma.client.create({ data: { name: "Harborline Logistics", contact: "pm@harborline.example" } });
  const clientC = await prisma.client.create({ data: { name: "Fernbank Health", contact: "it@fernbank.example" } });

  const projectA = await prisma.project.create({
    data: { name: "Storefront Revamp", description: "E-commerce redesign", clientId: clientA.id, ownerId: pm1.id },
  });
  const projectB = await prisma.project.create({
    data: { name: "Fleet Tracker", description: "Real-time fleet dashboard", clientId: clientB.id, ownerId: pm1.id },
  });
  const projectC = await prisma.project.create({
    data: { name: "Patient Portal", description: "Appointment scheduling portal", clientId: clientC.id, ownerId: pm2.id },
  });

  const daysFromNow = (n: number) => new Date(Date.now() + n * 24 * 60 * 60 * 1000);

  type SeedTask = { project: typeof projectA; title: string; assignee: typeof dev1; status: TaskStatus; priority: TaskPriority; dueDate: Date; overdue?: boolean };

  const tasks: SeedTask[] = [
    { project: projectA, title: "Build product listing page", assignee: dev1, status: TaskStatus.IN_PROGRESS, priority: TaskPriority.HIGH, dueDate: daysFromNow(5) },
    { project: projectA, title: "Integrate payment gateway", assignee: dev2, status: TaskStatus.TODO, priority: TaskPriority.CRITICAL, dueDate: daysFromNow(-2), overdue: true },
    { project: projectA, title: "Cart persistence bug", assignee: dev1, status: TaskStatus.IN_REVIEW, priority: TaskPriority.MEDIUM, dueDate: daysFromNow(3) },
    { project: projectA, title: "Mobile nav polish", assignee: dev2, status: TaskStatus.DONE, priority: TaskPriority.LOW, dueDate: daysFromNow(-1) },
    { project: projectA, title: "SEO metadata pass", assignee: dev1, status: TaskStatus.TODO, priority: TaskPriority.LOW, dueDate: daysFromNow(10) },

    { project: projectB, title: "Live map WebSocket feed", assignee: dev3, status: TaskStatus.IN_PROGRESS, priority: TaskPriority.CRITICAL, dueDate: daysFromNow(4) },
    { project: projectB, title: "Driver check-in API", assignee: dev4, status: TaskStatus.TODO, priority: TaskPriority.HIGH, dueDate: daysFromNow(-3), overdue: true },
    { project: projectB, title: "Route history export", assignee: dev3, status: TaskStatus.TODO, priority: TaskPriority.MEDIUM, dueDate: daysFromNow(8) },
    { project: projectB, title: "Geofence alerts", assignee: dev4, status: TaskStatus.IN_REVIEW, priority: TaskPriority.HIGH, dueDate: daysFromNow(2) },
    { project: projectB, title: "Fuel usage report", assignee: dev3, status: TaskStatus.DONE, priority: TaskPriority.LOW, dueDate: daysFromNow(1) },

    { project: projectC, title: "Appointment calendar UI", assignee: dev4, status: TaskStatus.IN_PROGRESS, priority: TaskPriority.HIGH, dueDate: daysFromNow(6) },
    { project: projectC, title: "HIPAA-compliant audit log", assignee: dev2, status: TaskStatus.TODO, priority: TaskPriority.CRITICAL, dueDate: daysFromNow(5) },
    { project: projectC, title: "Reminder SMS integration", assignee: dev4, status: TaskStatus.TODO, priority: TaskPriority.MEDIUM, dueDate: daysFromNow(9) },
    { project: projectC, title: "Provider availability sync", assignee: dev2, status: TaskStatus.IN_REVIEW, priority: TaskPriority.HIGH, dueDate: daysFromNow(3) },
    { project: projectC, title: "Accessibility audit", assignee: dev4, status: TaskStatus.DONE, priority: TaskPriority.MEDIUM, dueDate: daysFromNow(-1) },
  ];

  for (const t of tasks) {
    const created = await prisma.task.create({
      data: {
        projectId: t.project.id,
        title: t.title,
        description: `${t.title} for ${t.project.name}`,
        assigneeId: t.assignee.id,
        status: t.status,
        priority: t.priority,
        dueDate: t.dueDate,
        isOverdue: !!t.overdue,
      },
    });

    await prisma.activityLog.create({
      data: {
        projectId: t.project.id,
        taskId: created.id,
        actorId: t.assignee.id,
        action: "TASK_CREATED",
        message: `Task "${t.title}" was created and assigned to ${t.assignee.name}`,
      },
    });

    if (t.status !== TaskStatus.TODO) {
      await prisma.activityLog.create({
        data: {
          projectId: t.project.id,
          taskId: created.id,
          actorId: t.assignee.id,
          action: "STATUS_CHANGE",
          fromValue: "TODO",
          toValue: t.status,
          message: `${t.assignee.name} moved "${t.title}" from To Do \u2192 ${t.status.replace("_", " ")}`,
        },
      });
    }
  }

  console.log("Seed complete.");
  console.log("Login as: admin@velozity.com / sofia.pm@velozity.com / ravi.dev@velozity.com (password: Password123!)");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
