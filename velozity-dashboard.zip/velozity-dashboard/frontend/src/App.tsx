import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { useSocket } from "./hooks/useSocket";
import { NotificationBell } from "./components/NotificationBell";
import { Login } from "./pages/Login";
import { AdminDashboard } from "./pages/AdminDashboard";
import { PMDashboard } from "./pages/PMDashboard";
import { DeveloperDashboard } from "./pages/DeveloperDashboard";

function Shell() {
  const { user, loading, logout } = useAuth();
  const socketRef = useSocket();

  if (loading) return <p className="center-loading">Loading…</p>;
  if (!user) return <Login />;

  return (
    <div className="app-shell">
      <header>
        <h1>Velozity</h1>
        <div className="header-right">
          <span className="role-tag">
            {user.name} · {user.role}
          </span>
          <NotificationBell socketRef={socketRef} />
          <button onClick={logout}>Log out</button>
        </div>
      </header>
      <main>
        {user.role === "ADMIN" && <AdminDashboard socketRef={socketRef} />}
        {user.role === "PM" && <PMDashboard socketRef={socketRef} />}
        {user.role === "DEVELOPER" && <DeveloperDashboard socketRef={socketRef} />}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="*" element={<Shell />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
