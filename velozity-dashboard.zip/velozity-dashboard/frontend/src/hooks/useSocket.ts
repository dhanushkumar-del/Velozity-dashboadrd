import { useEffect, useRef } from "react";
import { io, Socket } from "socket.io-client";
import { getAccessToken, API_URL } from "../api/client";
import { useAuth } from "../context/AuthContext";

export function useSocket(): React.MutableRefObject<Socket | null> {
  const { user } = useAuth();
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    if (!user) return;
    const token = getAccessToken();
    if (!token) return;

    const socket = io(API_URL, { auth: { token }, withCredentials: true });
    socketRef.current = socket;

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
    // Reconnects whenever the user session (and thus token) changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  return socketRef;
}
