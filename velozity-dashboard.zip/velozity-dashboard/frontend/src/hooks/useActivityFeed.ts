import { useEffect, useRef, useState } from "react";
import { Socket } from "socket.io-client";
import { api } from "../api/client";
import { ActivityEvent } from "../types";

/**
 * Combines the live socket stream with a DB-backed catchup fetch. On mount
 * (and on socket "connect", which also fires after a dropped-connection
 * reconnect) we ask the server for anything created after the last event we
 * already have — this is what satisfies "offline users see the last 20
 * missed events, fetched from the database, not cached in memory."
 */
export function useActivityFeed(socketRef: React.MutableRefObject<Socket | null>) {
  const [events, setEvents] = useState<ActivityEvent[]>([]);
  const lastSeenRef = useRef<string | null>(null);

  useEffect(() => {
    async function catchUp() {
      const params = lastSeenRef.current ? { since: lastSeenRef.current } : {};
      const res = await api.get("/activity", { params });
      const fetched: ActivityEvent[] = res.data.data;
      if (fetched.length > 0) {
        setEvents((prev) => dedupeMerge(fetched.reverse(), prev));
        lastSeenRef.current = fetched[fetched.length - 1].createdAt;
      }
    }

    catchUp();

    const socket = socketRef.current;
    if (!socket) return;

    const onConnect = () => catchUp();
    const onActivity = (event: ActivityEvent) => {
      setEvents((prev) => dedupeMerge([event], prev));
      lastSeenRef.current = event.createdAt;
    };

    socket.on("connect", onConnect);
    socket.on("activity:new", onActivity);

    return () => {
      socket.off("connect", onConnect);
      socket.off("activity:new", onActivity);
    };
  }, [socketRef.current]);

  return events;
}

function dedupeMerge(newer: ActivityEvent[], older: ActivityEvent[]): ActivityEvent[] {
  const seen = new Set(older.map((e) => e.id));
  const merged = [...newer.filter((e) => !seen.has(e.id)), ...older];
  return merged.slice(0, 50);
}
