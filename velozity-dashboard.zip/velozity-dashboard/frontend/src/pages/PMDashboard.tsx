import { useEffect, useState } from "react";
import { Socket } from "socket.io-client";
import { api } from "../api/client";
import { ActivityFeed } from "../components/ActivityFeed";
import { TaskList } from "../components/TaskList";
import { useActivityFeed } from "../hooks/useActivityFeed";
import { Project, Task } from "../types";

interface PMStats {
  projects: Project[];
  tasksByPriority: { priority: string; _count: number }[];
  upcomingDue: Task[];
}

export function PMDashboard({ socketRef }: { socketRef: React.MutableRefObject<Socket | null> }) {
  const [stats, setStats] = useState<PMStats | null>(null);
  const [selectedProject, setSelectedProject] = useState<string | undefined>();
  const events = useActivityFeed(socketRef);

  useEffect(() => {
    api.get("/dashboard").then((res) => setStats(res.data.data));
  }, []);

  if (!stats) return <p>Loading…</p>;

  return (
    <div className="dashboard">
      <h2>Project Manager Dashboard</h2>

      <div className="stat-cards">
        <div className="stat-card">
          <span className="stat-value">{stats.projects.length}</span>
          <span className="stat-label">My Projects</span>
        </div>
        <div className="stat-card">
          <span className="stat-value">{stats.upcomingDue.length}</span>
          <span className="stat-label">Due This Week</span>
        </div>
      </div>

      <div className="task-status-breakdown">
        {stats.tasksByPriority.map((p) => (
          <span key={p.priority} className="status-chip">
            {p.priority}: {p._count}
          </span>
        ))}
      </div>

      <div className="project-tabs">
        <button className={!selectedProject ? "active" : ""} onClick={() => setSelectedProject(undefined)}>
          All my projects
        </button>
        {stats.projects.map((p) => (
          <button key={p.id} className={selectedProject === p.id ? "active" : ""} onClick={() => setSelectedProject(p.id)}>
            {p.name} ({p._count?.tasks ?? 0})
          </button>
        ))}
      </div>

      <div className="two-col">
        <div>
          <h3>Tasks</h3>
          <TaskList projectId={selectedProject} />
        </div>
        <div>
          <h3>My Projects' Activity</h3>
          <ActivityFeed events={events} />
        </div>
      </div>
    </div>
  );
}
