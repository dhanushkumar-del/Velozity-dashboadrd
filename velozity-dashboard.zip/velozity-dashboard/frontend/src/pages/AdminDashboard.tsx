import { useEffect, useState } from "react";
import { Socket } from "socket.io-client";
import { api } from "../api/client";
import { ActivityFeed } from "../components/ActivityFeed";
import { TaskList } from "../components/TaskList";
import { useActivityFeed } from "../hooks/useActivityFeed";

interface Stats {
  totalProjects: number;
  tasksByStatus: { status: string; _count: number }[];
  overdueCount: number;
  onlineUsers: number;
}

export function AdminDashboard({ socketRef }: { socketRef: React.MutableRefObject<Socket | null> }) {
  const [stats, setStats] = useState<Stats | null>(null);
  const [onlineNow, setOnlineNow] = useState(0);
  const events = useActivityFeed(socketRef);

  useEffect(() => {
    api.get("/dashboard").then((res) => {
      setStats(res.data.data);
      setOnlineNow(res.data.data.onlineUsers);
    });

    const socket = socketRef.current;
    if (!socket) return;
    const onPresence = (count: number) => setOnlineNow(count);
    socket.on("presence:count", onPresence);
    return () => {
      socket.off("presence:count", onPresence);
    };
  }, [socketRef.current]);

  if (!stats) return <p>Loading…</p>;

  return (
    <div className="dashboard">
      <h2>Admin Dashboard</h2>
      <div className="stat-cards">
        <div className="stat-card">
          <span className="stat-value">{stats.totalProjects}</span>
          <span className="stat-label">Total Projects</span>
        </div>
        <div className="stat-card">
          <span className="stat-value">{stats.overdueCount}</span>
          <span className="stat-label">Overdue Tasks</span>
        </div>
        <div className="stat-card">
          <span className="stat-value">{onlineNow}</span>
          <span className="stat-label">Online Now (live)</span>
        </div>
      </div>

      <div className="task-status-breakdown">
        {stats.tasksByStatus.map((s) => (
          <span key={s.status} className="status-chip">
            {s.status.replace("_", " ")}: {s._count}
          </span>
        ))}
      </div>

      <div className="two-col">
        <div>
          <h3>All Tasks</h3>
          <TaskList />
        </div>
        <div>
          <h3>Global Activity Feed</h3>
          <ActivityFeed events={events} />
        </div>
      </div>
    </div>
  );
}
