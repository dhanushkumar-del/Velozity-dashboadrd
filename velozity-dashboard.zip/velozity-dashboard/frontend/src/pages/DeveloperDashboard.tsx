import { Socket } from "socket.io-client";
import { ActivityFeed } from "../components/ActivityFeed";
import { TaskList } from "../components/TaskList";
import { useActivityFeed } from "../hooks/useActivityFeed";

export function DeveloperDashboard({ socketRef }: { socketRef: React.MutableRefObject<Socket | null> }) {
  // TaskList already scopes to "assigned to me" server-side for a Developer,
  // and is already sorted priority desc, dueDate asc by the API.
  const events = useActivityFeed(socketRef);

  return (
    <div className="dashboard">
      <h2>My Tasks</h2>
      <div className="two-col">
        <div>
          <TaskList />
        </div>
        <div>
          <h3>Activity on My Tasks</h3>
          <ActivityFeed events={events} />
        </div>
      </div>
    </div>
  );
}
