export type Role = "ADMIN" | "PM" | "DEVELOPER";
export type TaskStatus = "TODO" | "IN_PROGRESS" | "IN_REVIEW" | "DONE";
export type TaskPriority = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
}

export interface Task {
  id: string;
  projectId: string;
  title: string;
  description?: string | null;
  status: TaskStatus;
  priority: TaskPriority;
  dueDate?: string | null;
  isOverdue: boolean;
  assignee?: { id: string; name: string } | null;
  project?: { id: string; name: string };
}

export interface Project {
  id: string;
  name: string;
  description?: string | null;
  clientId: string;
  ownerId: string;
  client?: { name: string };
  _count?: { tasks: number };
}

export interface ActivityEvent {
  id: string;
  message: string;
  action: string;
  createdAt: string;
  actorId: string;
  actorName?: string;
  actor?: { name: string };
  taskId?: string | null;
}

export interface NotificationItem {
  id: string;
  message: string;
  isRead: boolean;
  createdAt: string;
  taskId?: string | null;
}
