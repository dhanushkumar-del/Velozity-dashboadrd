import { useEffect, useState } from "react";
import { Socket } from "socket.io-client";
import { api } from "../api/client";
import { NotificationItem } from "../types";

export function NotificationBell({ socketRef }: { socketRef: React.MutableRefObject<Socket | null> }) {
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [unread, setUnread] = useState(0);
  const [open, setOpen] = useState(false);

  async function load() {
    const res = await api.get("/notifications");
    setItems(res.data.data.notifications);
    setUnread(res.data.data.unreadCount);
  }

  useEffect(() => {
    load();
    const socket = socketRef.current;
    if (!socket) return;
    const onNew = (n: NotificationItem) => {
      setItems((prev) => [n, ...prev]);
      setUnread((c) => c + 1); // updates instantly via WebSocket push, no polling
    };
    socket.on("notification:new", onNew);
    return () => {
      socket.off("notification:new", onNew);
    };
  }, [socketRef.current]);

  async function markRead(id: string) {
    await api.patch(`/notifications/${id}/read`);
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, isRead: true } : i)));
    setUnread((c) => Math.max(0, c - 1));
  }

  async function markAllRead() {
    await api.patch("/notifications/read-all");
    setItems((prev) => prev.map((i) => ({ ...i, isRead: true })));
    setUnread(0);
  }

  return (
    <div className="notification-bell">
      <button onClick={() => setOpen((o) => !o)}>
        🔔 {unread > 0 && <span className="badge">{unread}</span>}
      </button>
      {open && (
        <div className="notification-dropdown">
          <div className="notification-dropdown-header">
            <strong>Notifications</strong>
            <button onClick={markAllRead}>Mark all read</button>
          </div>
          {items.length === 0 && <p className="empty-state">No notifications</p>}
          {items.map((n) => (
            <div key={n.id} className={`notification-row ${n.isRead ? "" : "unread"}`} onClick={() => markRead(n.id)}>
              {n.message}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
