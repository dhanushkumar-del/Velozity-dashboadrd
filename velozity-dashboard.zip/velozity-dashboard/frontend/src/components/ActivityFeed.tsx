import { ActivityEvent } from "../types";

function timeAgo(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min${mins === 1 ? "" : "s"} ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} hour${hours === 1 ? "" : "s"} ago`;
  const days = Math.floor(hours / 24);
  return `${days} day${days === 1 ? "" : "s"} ago`;
}

export function ActivityFeed({ events }: { events: ActivityEvent[] }) {
  if (events.length === 0) {
    return <p className="empty-state">No activity yet.</p>;
  }
  return (
    <ul className="activity-feed">
      {events.map((e) => (
        <li key={e.id} className="activity-item">
          <span className="activity-message">{e.message}</span>
          <span className="activity-time">· {timeAgo(e.createdAt)}</span>
        </li>
      ))}
    </ul>
  );
}
