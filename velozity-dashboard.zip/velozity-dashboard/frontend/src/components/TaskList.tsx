import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { api } from "../api/client";
import { Task } from "../types";

export function TaskList({ projectId, onStatusChange }: { projectId?: string; onStatusChange?: () => void }) {
  const [params, setParams] = useSearchParams();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  const status = params.get("status") || "";
  const priority = params.get("priority") || "";
  const dueBefore = params.get("dueBefore") || "";

  async function load() {
    setLoading(true);
    const query: Record<string, string> = {};
    if (projectId) query.projectId = projectId;
    if (status) query.status = status;
    if (priority) query.priority = priority;
    if (dueBefore) query.dueBefore = dueBefore;
    const res = await api.get("/tasks", { params: query });
    setTasks(res.data.data);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId, status, priority, dueBefore]);

  function updateFilter(key: string, value: string) {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value);
    else next.delete(key);
    setParams(next); // shareable as a URL, per the spec
  }

  async function changeStatus(taskId: string, newStatus: string) {
    await api.patch(`/tasks/${taskId}`, { status: newStatus });
    await load();
    onStatusChange?.();
  }

  return (
    <div className="task-list">
      <div className="filters">
        <select value={status} onChange={(e) => updateFilter("status", e.target.value)}>
          <option value="">All statuses</option>
          <option value="TODO">To Do</option>
          <option value="IN_PROGRESS">In Progress</option>
          <option value="IN_REVIEW">In Review</option>
          <option value="DONE">Done</option>
        </select>
        <select value={priority} onChange={(e) => updateFilter("priority", e.target.value)}>
          <option value="">All priorities</option>
          <option value="LOW">Low</option>
          <option value="MEDIUM">Medium</option>
          <option value="HIGH">High</option>
          <option value="CRITICAL">Critical</option>
        </select>
        <input type="date" value={dueBefore} onChange={(e) => updateFilter("dueBefore", e.target.value)} />
      </div>

      {loading ? (
        <p>Loading…</p>
      ) : tasks.length === 0 ? (
        <p className="empty-state">No tasks match these filters.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Title</th>
              <th>Assignee</th>
              <th>Priority</th>
              <th>Due</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((t) => (
              <tr key={t.id} className={t.isOverdue ? "overdue-row" : ""}>
                <td>{t.title}</td>
                <td>{t.assignee?.name || "Unassigned"}</td>
                <td>{t.priority}</td>
                <td>{t.dueDate ? new Date(t.dueDate).toLocaleDateString() : "—"}</td>
                <td>
                  <select value={t.status} onChange={(e) => changeStatus(t.id, e.target.value)}>
                    <option value="TODO">To Do</option>
                    <option value="IN_PROGRESS">In Progress</option>
                    <option value="IN_REVIEW">In Review</option>
                    <option value="DONE">Done</option>
                  </select>
                  {t.isOverdue && <span className="overdue-tag">Overdue</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
