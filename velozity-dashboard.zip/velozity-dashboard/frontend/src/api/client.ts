import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

// The access token lives ONLY in memory (a module-level variable), never in
// localStorage or sessionStorage — an XSS payload that runs JS on this page
// still can't exfiltrate it via storage APIs. The refresh token never
// touches JS at all; it's an httpOnly cookie the browser attaches
// automatically to /api/auth/refresh.
let accessToken: string | null = null;
export function setAccessToken(token: string | null) {
  accessToken = token;
}
export function getAccessToken() {
  return accessToken;
}

export const api = axios.create({
  baseURL: `${API_URL}/api`,
  withCredentials: true, // send the httpOnly refresh cookie
});

api.interceptors.request.use((config) => {
  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`;
  }
  return config;
});

let refreshPromise: Promise<string | null> | null = null;

async function refreshAccessToken(): Promise<string | null> {
  try {
    const res = await axios.post(`${API_URL}/api/auth/refresh`, {}, { withCredentials: true });
    const token = res.data.data.accessToken as string;
    setAccessToken(token);
    return token;
  } catch {
    setAccessToken(null);
    return null;
  }
}

api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true;
      // De-dupe concurrent 401s into a single refresh call.
      refreshPromise = refreshPromise || refreshAccessToken();
      const newToken = await refreshPromise;
      refreshPromise = null;
      if (newToken) {
        original.headers.Authorization = `Bearer ${newToken}`;
        return api(original);
      }
    }
    return Promise.reject(error);
  }
);

export { refreshAccessToken, API_URL };
