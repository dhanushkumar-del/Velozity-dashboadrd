Paste into the submission form's Explanation field (edit freely — this is ~230 words):

---

The hardest problem was making the real-time feed genuinely role-filtered
at the point of emission, not just filtered client-side after receiving
everything. My solution: every socket connection joins exactly one personal
room derived from its JWT role at connect time — `feed:global` for Admin,
`feed:pm:<id>` for a PM, `feed:dev:<id>` for a Developer — plus an optional
`project:<id>` room, joined only after a server-side permission check, when
a user opens that project's board. When a task's status changes, the server
computes the exact set of rooms entitled to see it (global, the owning PM,
the assignee, and anyone currently viewing that project) and emits only to
those. The client never receives data it isn't allowed to see, so there's
nothing to leak even if the client code were compromised or modified.

The second hard part was missed-event catchup: reconnecting clients call
`GET /api/activity?since=<last-seen>`, always reading from Postgres, never
from server memory, so it's correct after a server restart or days offline
— not just a dropped connection.

One thing I'd do differently: I'd move the overdue-flagging job and
activity-log writes onto a proper job queue (Bull/BullMQ) once the app has
more than one background job, so job failures get retries and observability
instead of a bare `cron.schedule` catch-and-log. For a single stateless
scan, node-cron was the right initial call, but it's the first thing I'd
outgrow.
