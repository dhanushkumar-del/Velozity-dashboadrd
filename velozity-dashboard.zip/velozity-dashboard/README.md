# Velozity Client Project Dashboard

Full-stack internal tool for managing client projects, tasks, and a
real-time, role-filtered activity feed.

## Stack

- **Frontend:** React + TypeScript (Vite), React Router, Socket.io-client
- **Backend:** Node.js + Express + TypeScript
- **DB:** PostgreSQL via Prisma
- **Real-time:** Socket.io
- **Background jobs:** node-cron
- **Auth:** JWT access token (in-memory, 15 min) + opaque refresh token
  (httpOnly cookie, 30 days, rotated on use)

## Local setup (Docker — recommended)

```bash
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
docker compose up --build
```

This starts Postgres, runs migrations, seeds the database, and starts both
servers. Frontend: http://localhost:5173. Backend: http://localhost:4000.

## Local setup (manual)

```bash
# Postgres must be running locally, matching backend/.env DATABASE_URL
cd backend
cp .env.example .env
npm install
npx prisma migrate dev --name init
npm run seed
npm run dev

# in a second terminal
cd frontend
cp .env.example .env
npm install
npm run dev
```

## Seed accounts (password for all: `Password123!`)

| Role | Email |
|---|---|
| Admin | admin@velozity.com |
| PM | sofia.pm@velozity.com |
| PM | daniel.pm@velozity.com |
| Developer | ravi.dev@velozity.com |
| Developer | maya.dev@velozity.com |
| Developer | tomas.dev@velozity.com |
| Developer | aisha.dev@velozity.com |

Seed creates 3 projects, 15 tasks (5 per project) across all four statuses,
2 tasks already overdue, and pre-existing activity log rows so the feed
isn't empty on first load.

## Database schema (see `backend/prisma/schema.prisma` for the source of truth)

- **User** (`role`: ADMIN/PM/DEVELOPER) — indexed on `role` (dashboards and
  assignee dropdowns filter by role constantly).
- **RefreshToken** — stores a SHA-256 hash of the token, never the token
  itself; indexed on `userId` for revoke-on-logout lookups.
- **Client** → **Project** (owned by a PM via `ownerId`) → **Task**.
  `Project.ownerId` is indexed because "my projects" is the PM dashboard's
  primary query.
- **Task** — indexed on `assigneeId` (developer dashboard), `projectId`,
  `status`, `priority`, `dueDate`, and `isOverdue` — every one of these is a
  column the filter UI or the overdue cron job queries directly.
- **ActivityLog** — indexed on `(projectId, createdAt)` as a composite,
  since the feed's core query is always "activity for project(s) X, ordered
  by time"; also indexed on `actorId` and `taskId`.
- **Notification** — indexed on `(userId, isRead)` for the unread badge
  count and `(userId, createdAt)` for the dropdown list.

## Architectural decisions

**WebSocket library — Socket.io, not raw `ws`.** The role-filtered feed
needs per-user and per-project *rooms* with dynamic join/leave and
automatic reconnection with a fresh auth handshake. Socket.io gives all of
that out of the box; raw WebSocket would mean hand-rolling a room registry,
reconnect/backoff logic, and connection-state recovery — solving a problem
Socket.io already solved, for no benefit here since we don't need to shed
its (small) message-framing overhead.

**Room strategy (the real-time role-filtering, see `socket.service.ts`):**
every connection joins exactly one personal feed room based on its JWT role
(`feed:global` / `feed:pm:<id>` / `feed:dev:<id>`), and optionally a
per-project room (`project:<id>`) when the user opens that project's page —
membership in that room is permission-checked server-side at join time
(PM must own it, Developer must have a task in it). When a task's status
changes, the server computes the exact set of rooms entitled to see it
(global + owning PM + assignee + anyone currently viewing that project) and
emits to precisely those rooms. The client never receives, and therefore
never has to filter out, data it isn't allowed to see.

**Missed-event catchup:** the client always calls
`GET /api/activity?since=<last-seen-timestamp>` on mount and on socket
`connect` (which also fires after a reconnect). This always hits Postgres —
nothing is buffered in server memory — so it works after a page reload, a
server restart, or being offline for days.

**node-cron over Bull for the overdue scheduler.** The job is a single
stateless "scan `Task` where `dueDate < now` and flip a boolean" — no
per-item retry/backoff semantics, no payload, no cross-worker coordination.
Bull's Redis dependency buys nothing here. It would earn its place for
something like "email retries with exponential backoff," which this isn't.

**Refresh token in an httpOnly cookie, access token in memory only** (never
localStorage/sessionStorage). This is the standard mitigation for XSS token
theft: a JS-executing payload can still make same-origin requests, but it
can't read the cookie or exfiltrate a token that isn't in any
JS-accessible storage. The refresh token itself is stored server-side only
as a SHA-256 hash and rotated (old one revoked) on every use, so a
captured-in-transit-but-already-used token can't be replayed.

**Role enforcement lives in the API, not the UI.** Every protected route
runs through `requireAuth` (verifies the JWT signature) and, where
applicable, `requireRole(...)`. Ownership/assignment checks
(`assertProjectAccess`, `loadTaskWithAccessCheck`) run inside controllers
against the *database's* record of who owns/is-assigned-to what — never
against anything the client sent. A Developer that edits their JWT payload
fails signature verification; a Developer with a *valid* token for another
developer's task gets a clean 403 from the DB-backed ownership check.

## Known limitations

- Not deployed live / not pushed to a hosted repo from this environment —
  see the note at the top of this conversation. Follow the setup steps
  above to run and then push/deploy yourself (`git init`, push to
  GitHub/GitLab, `vercel --prod` for the frontend; the backend + Postgres
  need a host with a persistent process and WebSocket support, e.g.
  Render/Railway/Fly — Vercel's serverless functions don't hold a
  long-lived Socket.io connection well).
- No automated test suite (unit/integration) — given the time box, effort
  went into the API-level access control and the real-time fan-out logic
  instead.
- CSS is intentionally minimal/utilitarian, not a polished design system.
- Task reassignment notifications only fire on `assigneeId` change via
  `PATCH /tasks/:id`; there's no bulk-reassign endpoint.
- No pagination on the activity feed or task list beyond the last-50/last-20
  caps — fine at seed-data scale, would need cursor pagination at real
  volume.
